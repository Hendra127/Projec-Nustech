// $.ajax({
//     url: "/api/data",
//     method: "GET",
//     success: function (response) {
//         console.log(response);
//     },
//     error: function (xhr) {
//         console.error(xhr);
//     },
// });
