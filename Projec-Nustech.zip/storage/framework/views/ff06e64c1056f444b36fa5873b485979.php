

<?php $__env->startSection('auth'); ?>

    <?php if(\Request::is('static-sign-up')): ?>
        <?php echo $__env->make('layouts.navbars.guest.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.footers.guest.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php elseif(\Request::is('static-sign-in')): ?>
        <?php echo $__env->make('layouts.navbars.guest.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.footers.guest.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php else: ?>
        <?php if(\Request::is('rtl')): ?>
            <?php echo $__env->make('layouts.navbars.auth.sidebar-rtl', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg overflow-hidden">
                <?php echo $__env->make('layouts.navbars.auth.nav-rtl', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="container-fluid py-4">
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('layouts.footers.auth.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </main>

        <?php elseif(\Request::is('profile')): ?>
            <?php echo $__env->make('layouts.navbars.auth.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="main-content position-relative bg-gray-100 max-height-vh-100 h-100">
                <?php echo $__env->make('layouts.navbars.auth.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>

        <?php elseif(\Request::is('virtual-reality')): ?>
            <?php echo $__env->make('layouts.navbars.auth.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="border-radius-xl mt-3 mx-3 position-relative" style="background-image: url('../assets/img/vr-bg.jpg') ; background-size: cover;">
                <?php echo $__env->make('layouts.navbars.auth.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <main class="main-content mt-1 border-radius-lg">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
            <?php echo $__env->make('layouts.footers.auth.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php else: ?>
            <?php echo $__env->make('layouts.navbars.auth.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg <?php echo e((Request::is('rtl') ? 'overflow-hidden' : '')); ?>">
                <?php echo $__env->make('layouts.navbars.auth.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="container-fluid py-4">
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('layouts.footers.auth.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </main>
        <?php endif; ?>

        <?php echo $__env->make('components.fixed-plugin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <!-- Tambahan Script Bootstrap & jQuery -->
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Projec-Nustech\resources\views/layouts/user_type/auth.blade.php ENDPATH**/ ?>